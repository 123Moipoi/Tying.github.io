# GAME DAY — Sports Store Demo

A responsive, self-contained front-end demo for a fictional sports equipment retailer.

## Run locally
Open `index.html` in a modern browser, or serve this folder with any static web server.

## Included
- 1,000 generated fictional products across 21 sports
- Unique generated product names, SKUs, model identifiers, demo prices, materials and stock counts
- Search, sport/brand/type/price filters, sorting and pagination
- Product detail drawer, size selection, wishlist and persistent demo cart
- Local demo account, order history, and simulated unpaid test checkout
- Responsive mobile layout and fictional product illustrations generated as SVGs

## Important limitations
This is a front-end prototype, not a production e-commerce system. Browser `localStorage` is used only for demo persistence on one browser/device. Authentication is not secure, carts do not sync across devices, and checkout does not take payment. The illustrations are generated vector product concepts, not photorealistic product photography. No real inventory, shipping, refunds, legal policies, or fulfilment are connected.

## Production next steps
Use a real backend/database (e.g. PostgreSQL with Supabase), server-side authorization and secure sessions, object storage for individually art-directed product photography, and Stripe Checkout in test mode with signed webhook verification. Store inventory and orders server-side, calculate totals on the server, and never trust client-provided prices or payment status.
